﻿using System;
using System.IO;
using System.Collections.Generic;

namespace CommunityEvents;
 

class Program
{
    static void Main(string[] args)
    {
        ConsoleUI userInterface = new ConsoleUI();
        userInterface.Show();
    }
}
